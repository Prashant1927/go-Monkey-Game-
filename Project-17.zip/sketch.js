
var monkey , monkey_running;
var banana ,bananaImage, obstacle, obstacleImage;
var FoodGroup, obstacleGroup;
var ground,invisibleGround;
var score;
var survivalTime = 0;



function preload(){
  
  monkey_running = loadAnimation("monkey_0.png","monkey_1.png","monkey_2.png","monkey_3.png","monkey_4.png","monkey_5.png","monkey_6.png","monkey_7.png","monkey_8.png")
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
  
}



function setup() {
  //creating Monkey
  monkey = createSprite(80,315,20,20);
  monkey.addAnimation("moving",monkey_running);
  monkey.scale = 0.1;

  ground = createSprite(400,350,900,10);
  ground.velocityX = -4;
  ground.x = ground.width/2;
  console.log(ground.x);
  
  invisibleGround = createSprite(400,350,900,10);
  invisibleGround.visible = false;
  
  FoodGroup = new Group();
  obstacleGroup = new Group();
  
  score = 0;
}


function draw() {
  background("white");
  
  stroke("white");
  textSize(20);
  fill("white");
  text("Score: "+ score,500,50);
  
  stroke("black");
  textSize(20);
  fill("black");
  survivalTime = Math.ceil(frameCount/frameRate())
  text("Survival Time : "+ survivalTime ,100,50);
  
   //jump when space is pressed
  if(keyDown("space")&& monkey.y >= 100) {
    monkey.velocityY = -13;
  }
   //add Gravity
  monkey.velocityY = monkey.velocityY + 0.8
  
    if (ground.x < 0){
      ground.x = ground.width/2;
    }
  monkey.collide(invisibleGround);

  obstacle()
  banana()
  drawSprites()  
}

function reset()
{
  
}

function banana(){
  if(frameCount % 80 ===0){
    var banana = createSprite(200,165,20,20);
    banana.y = Math.round(random(120,200));
    banana.addImage(bananaImage);
    banana.scale = 0.1;
    banana.velocityX = -3;
    banana.lifetime = 500;
    FoodGroup.add(banana);
}
}

function obstacle(){
  if(frameCount % 300 ===0){
    var obstacle = createSprite(200,330,20,20);
    obstacle.addImage(obstacleImage);
    obstacle.scale = 0.1;
    obstacle.velocityX = -3;
    obstacle.lifetime = 100;
    obstacleGroup.add(obstacle);
}  
}


